
README for Datasets
===================

File: MockupPostQ.csv
---------------------

Post-questionnaire data from paper

G.Scanniello, F.Ricca, M.Torchiano, G.Reggio, E.Astesiano "Assessing the Effect of Screen Mockups on the Comprehension of Functional Requirements" ACM TRANSACTIONS ON SOFTWARE ENGINEERING AND METHODOLOGY, Vol.24, pp.1:1-1:38, 2014


FIELD | Description
------|-----------------------------------------------------
Exp   | Experiment where data was collected
Id    | Subject ID
Group | Experimental group the subject belongs to
Q1    | I had enough time to perform the tasks.
Q2    | The questions of the comprehension questionnaire were clear to me.
Q3    | I did not have any issue in comprehending the use cases.
Q4    | I did not have any issue in comprehending the use case diagrams.
Q5    | I found the exercise useful.
Q6    | I found screen mockups useful (when present)
Q7    | The time I spend looking at screen mockups (when present) (in terms of percentage with respect to the total time to accomplish the task (A-E)

Coding of the answers to items Q1 - Q6:

(1) strongly agree,
(2) agree,
(3) neither agree nor disagree,
(4) disagree,
(5) strongly disagree. 

Coding of the answers to item Q7:

(A) < 20%,
(B) $>$ 20% and ≤ 40%, 
(C) $>$ 40% and ≤ 60%,
(D) $>$ 60% and ≤ 80%,
(E) ≥ 80%

File: ICSE08_raw-data.csv
-------------------------

Raw data from paper:

Ricca, Filippo; Di Penta, Massimiliano; Torchiano, Marco; Tonella, Paolo; Ceccato, Mariano; Visaggio, Corrado Aaron
Are Fit Tables Really Talking? A Series of Experiments to Understand whether Fit Tables are Useful during Evolution Tasks
in Proc. IEEE International Conference on Software Engineering, pp.361--370
(DOI: 10.1145/1368088.1368138)

<http://www.rcost.unisannio.it/mdipenta/Fit-Package.zip>


Field         | Description
--------------|----------------------------------------
ExpName       | Name of the experiment (location) in the family
Id            | Subject ID
Complete      | Completion level (from 0 to 1)
System        | System the subject worked on (object)
Fit           | Presence of FIT tests
Lab           | Lab session number
installTime   | Time used to perform installation
TimeT1        | Time to perform Task 1
TimeT2        | Time to perform Task 2
TimeT3        | Time to perform Task 3
TimeT4        | Time to perform Task 4
TimeTotal     | Total experiment time
TotalTask     | Totale time to perform all four tasks
Exp           | Experiment label (and graduation level)


